from django.shortcuts import get_object_or_404, render
from .models import Post
def read_article(request,slug):
    obj=get_object_or_404(Post,slug=slug)
    template_name="read.html"
    context={'object':obj}
    return render(request,template_name,context)
def home(request):
    qs=Post.objects.all()
    
    template_name="home.html"
    context={'object_list':qs}
    return render(request,template_name,context)    
# Create your views here.
#def home(request):
   # return render(request,'home.html')
#def read(request):
    #return render(request,'read.html')    